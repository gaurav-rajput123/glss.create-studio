import React from "react"


export const formContext = React.createContext(new FormData())
// module.exports = formContext
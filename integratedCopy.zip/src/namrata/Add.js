import React from "react";
import {Button} from "@mui/material";





export default function AddComponent() {
    return(
        <Button variant="contained" sx={{ minWidth: "20% !important" , backgroundColor:'#375dbe'}}>
           Add Component
        </Button>
    )
}

 